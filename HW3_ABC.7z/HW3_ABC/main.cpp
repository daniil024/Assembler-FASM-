#include <iostream>
#include <vector>
#include <thread>


int number_of_sep = 100;    // Кол-во разбиений на прямоугольники.
std::vector<double> value_of_threads;


std::vector<double> input_a_b() {
    std::vector<double> v;
    double a,b;
    std::cout << "Для нахождения интеграла функции f(x) = 2x^2 + 1 "
                 "введите нижний предел A(больше -1) и через пробел верхний предел B(больше A)" << std::endl;
    std::cin >> a >> b;
    v.push_back(a);
    v.push_back(b);
    if (v[1] < v[0] || v[0] < -1) {
        std::cout << "Вы ввели неверные значения. Попробуйте снова!\n";
        input_a_b();
    };
    return v;
};

void rectangle(int number_of_vector, int threads_size, double a) {
    double result = 0;
    for (int i = number_of_vector; i < number_of_sep; i += threads_size) {
        double x = a + 0.01 * i;
        double res = 0.01 * 2*pow(x, 2) + 1;
        result += res;
    }
    value_of_threads.resize(value_of_threads.size()+1);
    value_of_threads[number_of_vector] = result;
}

void res(double a, double b) {
    int threads_size = std::thread::hardware_concurrency();
    std::thread *threads = new std::thread[threads_size];

    double step = (b-a) / number_of_sep;
    for (int i = 0; i < threads_size; i++) {
        threads[i] = std::thread(rectangle, i, threads_size, a);
        threads[i].join();
        a += step;
    }

}

int main() {
    std::vector<double> a_b = input_a_b();

    res(a_b[0], a_b[1]);

    double result = 0;
    for (int i = 0; i < value_of_threads.size(); ++i) {
        result += value_of_threads[i];
    }

    std::cout << result;
    return 0;
}
